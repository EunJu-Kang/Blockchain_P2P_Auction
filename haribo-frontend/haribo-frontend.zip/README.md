# haribo-frontend-base
Frontend Base Project for Blockchain-based P2P Auction
